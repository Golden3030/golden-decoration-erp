"use client";

import { useEffect, useState, useMemo } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import Sidebar from "@/components/layout/Sidebar";
import Header from "@/components/layout/Header";

import CRMSearch from "@/components/CRM/CRMSearch";
import CustomerInfo from "@/components/CRM/CustomerInfo";
import ProjectInfo from "@/components/CRM/ProjectInfo";
import FinishingTabs from "@/components/CRM/FinishingTabs";
import { useCRM, DEFAULT_FINISHING_SCHEMA } from "@/components/CRM/context/CRMContext";
import { supabase } from "@/lib/supabaseClient";
import { isOnline, addToOfflineQueue } from "@/lib/offline-sync";
import { Plus, Minus, UserPlus, Search, Check } from "lucide-react";

interface CustomerLog {
  id: string;
  interaction_type: string;
  text: string;
  feedback: string;
  next_follow_up_date: string;
  created_at: string;
  sender_name?: string;
}

const roleLabels: { [key: string]: string } = {
  admin: "مدير النظام 👑",
  manager: "مدير الحسابات والتشغيل 💵",
  sales_manager: "مدير مبيعات (CRM) 📊",
  sales: "موظف مبيعات (سيلز) 📈",
  procurement: "موظف مشتريات ومخازن 📦",
  engineer: "مهندس الموقع الميداني 🏗️",
  client: "العميل النهائي صاحب الوحدة 👤"
};

export default function CRMPage() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const { crmData, setCRMData, loadProjectData, saveEstimateSnapshot, isLocked } = useCRM();

  const [saving, setSaving] = useState(false);
  const [loading, setLoading] = useState(true);
  const [isSearchOpen, setIsSearchOpen] = useState(false);

  const [isAddCustomerOpen, setIsAddCustomerOpen] = useState(false);
  const [addName, setAddName] = useState("");
  const [addMobile, setAddMobile] = useState("");
  const [addPhone, setAddPhone] = useState("");
  const [addEmail, setAddEmail] = useState("");
  const [addAddress, setAddAddress] = useState("");
  const [addAssignedTo, setAddAssignedTo] = useState("");
  const [addStatus, setAddStatus] = useState("جديد");

  // تقدير مبدئي قادم من مساعد المبيعات الذكي: يُنقل لمشروع العميل بعد تسجيله فعلياً
  const [leadDraft, setLeadDraft] = useState<any>(null);

  const [customersList, setCustomersList] = useState<any[]>([]);
  const [projectsList, setProjectsList] = useState<any[]>([]);
  const [selectedStatus, setSelectedStatus] = useState<string>("all");

  const [userRole, setUserRole] = useState<string>("sales");
  const [currentUserId, setCurrentUserId] = useState<string>("");
  const [salesStaff, setSalesStaff] = useState<any[]>([]); 
  const [selectedSalesFilter, setSelectedSalesFilter] = useState<string>("all");

  const [isFollowUpOpen, setIsFollowUpOpen] = useState(false);
  const [followUpType, setFollowUpType] = useState("مكالمة هاتفية");
  const [followUpFeedback, setFollowUpFeedback] = useState("");
  const [followUpNextDate, setFollowUpNextDate] = useState("");
  const [customerLogs, setCustomerLogs] = useState<CustomerLog[]>([]);
  const [loadingLogs, setLoadingLogs] = useState(false);

  const [visibleLogsCount, setVisibleLogsCount] = useState<number>(5);

  const [selectedCustomerProjects, setSelectedCustomerProjects] = useState<any[]>([]);

  // مصفوفة وتنسيق خطوات سير العمل الخماسي للشركة
  const workflowStages = [
    { key: "pending_specs", label: "تجهيز المواصفات", icon: "📐" },
    { key: "needs_estimate", label: "طلب التسعير", icon: "⏳" },
    { key: "initial_ready", label: "المقايسة المبدئية", icon: "📄" },
    { key: "amendments_requested", label: "تعديلات مطلوبة", icon: "🛠️" },
    { key: "final", label: "التعاقد النهائي", icon: "👑" }
  ];

  const getCurrentStageIndex = (currentStage: string) => {
    const s = String(currentStage || "").trim().toLowerCase();
    if (s === "needs_estimate") return 1;
    if (s === "initial_ready") return 2;
    if (s === "amendments_requested") return 3;
    if (s === "final") return 4;
    return 0; // pending_specs
  };

  // حالة تخزين واستدعاء تقدير حاسبة الإعلانات الخارجية
  const [calculatorEstimate, setCalculatorEstimate] = useState<{min: number, max: number} | null>(null);

  const isManager = ["admin", "owner", "manager", "sales_manager"].includes(userRole.toLowerCase());

  useEffect(() => {
    document.title = "Golden Decoration ERP - الـ CRM وسجل بيانات العملاء والمتابعات";
    loadAllCRMData();
  }, []);

  // ✅ لو الرابط جاي من مكان تاني (زي زرار "مشروع جديد لنفس العميل" فى ملف العميل) ومعاه
  // ?customer_id=، نجيب بيانات العميل ده ونبدأله مشروع جديد تلقائياً بدل ما يتسجل من الصفر
  // ✅ لو الرابط جاي من مكان تاني (زي زرار "مشروع جديد لنفس العميل" فى ملف العميل، أو من
  // إشعار "طلب تسعير معلق") ومعاه ?customer_id= أو ?project_id=، نجيب البيانات المناسبة تلقائياً
  // فتح نموذج "إضافة عميل جديد" تلقائياً لو الطلب جاي من زرار "طلب مقايسة مبدئية" في مساعد المبيعات
  useEffect(() => {
    if (searchParams.get("newLead") !== "1") return;
    try {
      const raw = sessionStorage.getItem("salesLeadDraft");
      if (!raw) return;
      const draft = JSON.parse(raw);
      if (!draft?.createdAt || Date.now() - draft.createdAt > 2 * 60 * 60 * 1000) {
        sessionStorage.removeItem("salesLeadDraft"); // مسودة قديمة
        return;
      }
      setLeadDraft(draft);
      setAddAddress(draft.location || "");
      setIsAddCustomerOpen(true);
    } catch (e) {
      console.warn("تعذّر قراءة مسودة مساعد المبيعات", e);
    }
  }, [searchParams]);

  useEffect(() => {
    const customerIdParam = searchParams.get("customer_id");
    const projectIdParam = searchParams.get("project_id");
    if ((!customerIdParam && !projectIdParam) || loading) return; // نستنى لحد ما يخلص التحميل الأساسي الأول (المشاريع، إلخ) لتجنب أي تعارض فى البيانات

    (async () => {
      if (projectIdParam) {
        // فتح مشروع موجود بالفعل بالظبط (زي لما مهندس يدوس على إشعار طلب تسعير معلق)
        const { data: existingProject } = await supabase
          .from("projects")
          .select("customer_id")
          .eq("id", projectIdParam)
          .maybeSingle();

        if (existingProject?.customer_id) {
          const { data: existingCustomer } = await supabase
            .from("customers")
            .select("*")
            .eq("id", existingProject.customer_id)
            .maybeSingle();

          if (existingCustomer) {
            await handleSelectCustomerFromGrid(existingCustomer);
            await handleSwitchActiveProject(projectIdParam);
          }
        }
        return;
      }

      if (customerIdParam) {
        const { data: existingCustomer } = await supabase
          .from("customers")
          .select("*")
          .eq("id", customerIdParam)
          .maybeSingle();

        if (existingCustomer) {
          await handleSelectCustomerFromGrid(existingCustomer);
        }
      }
    })();
  }, [searchParams, loading]);

  // 🌟 استعلام أوتوماتيكي ذكي لمنع الانهيارات واستخراج أحدث طلب مسجل للحاسبة لهذا الهاتف تلقائياً
  useEffect(() => {
    if (!crmData.customer?.mobile) {
      setCalculatorEstimate(null);
      return;
    }
    const checkCalculatorEstimate = async () => {
      try {
        const cleanPhone = String(crmData.customer.mobile).trim();
        const { data } = await supabase
          .from("customer_requests")
          .select("estimatedMin, estimatedMax")
          .eq("phone", cleanPhone)
          .order("created_at", { ascending: false }) // جلب أحدث ليد لمنع انهيار مبيعاتي عند تكرار التجريب
          .limit(1);
        
        if (data && data.length > 0) {
          setCalculatorEstimate({
            min: Number(data[0].estimatedMin || 0),
            max: Number(data[0].estimatedMax || 0)
          });
        } else {
          setCalculatorEstimate(null);
        }
      } catch (err) {
        console.error("Error fetching calculator estimate:", err);
      }
    };
    checkCalculatorEstimate();
  }, [crmData.customer?.mobile]);

  // دالة معالجة وتنسيق التاريخ والوقت التاريخي للمتابعة بشكل لائق
  const formatTimelineDate = (dateStr: string) => {
    if (!dateStr) return "تاريخ غير محدد";
    try {
      const d = new Date(dateStr);
      if (isNaN(d.getTime())) return dateStr;
      return d.toLocaleDateString("ar-EG", {
        year: "numeric",
        month: "short",
        day: "numeric",
        hour: "2-digit",
        minute: "2-digit",
        hour12: true
      });
    } catch (e) {
      return dateStr;
    }
  };

  // ✅ إصلاح: كانت الأكواد (CUST/P/EST) بتتولد عشوائياً بالكامل، فمكنش فيها أي تسلسل منطقي.
  // الدالة دي بتجيب أعلى رقم مسجل فعلياً بنفس البادئة، وترجع الرقم اللي بعده مباشرة
  async function generateSequentialCode(table: string, column: string, prefix: string): Promise<string> {
    try {
      const { data, error } = await supabase
        .from(table)
        .select(column)
        .ilike(column, `${prefix}-%`);

      if (error) throw error;

      let maxNum = 1000;
      (data || []).forEach((row: any) => {
        const val = row[column] as string;
        const match = val?.match(new RegExp(`^${prefix}-(\\d+)$`));
        if (match) {
          const num = parseInt(match[1], 10);
          if (num > maxNum) maxNum = num;
        }
      });
      return `${prefix}-${maxNum + 1}`;
    } catch (err) {
      console.error(`تعذر توليد كود متسلسل لـ ${prefix}، سيتم استخدام رقم عشوائي احتياطي:`, err);
      return `${prefix}-${Math.floor(1000 + Math.random() * 9000)}`;
    }
  }

  async function loadAllCRMData() {
    setLoading(true);
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        router.push("/");
        return;
      }
      setCurrentUserId(user.id);

      const { data: profile } = await supabase
        .from("users")
        .select("role")
        .eq("id", user.id)
        .single();

      const roleKey = String(profile?.role || "").toLowerCase();
      setUserRole(roleKey); 

      let customerQuery = supabase.from("customers").select("*");

      if (roleKey === "sales") {
        customerQuery = customerQuery.eq("assigned_to", user.id);
      } else {
        const { data: staff } = await supabase
          .from("users")
          .select("id, name")
          .eq("role", "sales")
          .order("name", { ascending: true });
        setSalesStaff(staff || []);
      }

      const [custRes, projRes] = await Promise.all([
        customerQuery.order("created_at", { ascending: false }),
        supabase.from("projects").select("*")
      ]);

      if (custRes.error) throw custRes.error;
      if (projRes.error) throw projRes.error;

      setCustomersList(custRes.data || []);
      setProjectsList(projRes.data || []);

    } catch (err: any) {
      console.error("Error loading CRM data:", err);
    } finally {
      setLoading(false);
    }
  }

  // إغلاق نموذج إضافة العميل (وإلغاء مسودة التقدير حتى لا تُنسب لعميل آخر بالغلط)
  function closeAddCustomer() {
    setIsAddCustomerOpen(false);
    setLeadDraft(null);
    try { sessionStorage.removeItem("salesLeadDraft"); } catch { /* تجاهل */ }
  }

  // بعد تسجيل العميل: نفتحه في الـ CRM وننقل بيانات التقدير المبدئي لمشروعه ليكمل المندوب ويحفظ
  async function applyLeadDraft(customer: any, draft: any) {
    await handleSelectCustomerFromGrid(customer);
    setCRMData((prev: any) => ({
      ...prev,
      activeTab: "المقايسة",
      project: {
        ...prev.project,
        projectName: `مشروع ${draft.area}م² ${draft.levelSpecified ? draft.levelLabel : ""} - ${customer.name}`.replace(/\s+/g, " "),
        estimateDate: new Date().toLocaleDateString("en-CA"),
        unitType: "شقة",
        area: draft.area,
        finishingLevel: draft.dbLevel,
        location: draft.location || prev.project?.location || "",
        unitAddress: draft.location || prev.project?.unitAddress || "",
        receptionsCount: draft.counts?.receptions ?? prev.project?.receptionsCount ?? 1,
        roomsCount: draft.counts?.bedrooms ?? prev.project?.roomsCount ?? 2,
        bathroomsCount: draft.counts?.bathrooms ?? prev.project?.bathroomsCount ?? 1,
        kitchensCount: draft.counts?.kitchens ?? prev.project?.kitchensCount ?? 1,
        // نفس منطق طلبات الحاسبة: القيمة التقديرية تبدأ بأدنى التقدير ويعدلها المندوب
        contractValue: draft.minCost || prev.project?.contractValue || 0
      }
    }));
    try { sessionStorage.removeItem("salesLeadDraft"); } catch { /* تجاهل */ }
    setLeadDraft(null);
  }

  async function handleInsertNewCustomer() {
    if (!addName || !addMobile) {
      alert("الرجاء إدخال اسم العميل ورقم المحمول لإتمام عملية التسجيل.");
      return;
    }

    setSaving(true);
    const assignedRepId = isManager ? (addAssignedTo || null) : currentUserId;
    const generatedCustomerCode = await generateSequentialCode("customers", "customer_code", "CUST");

    const payload = {
      customer_code: generatedCustomerCode,
      name: addName,
      mobile: addMobile,
      phone: addPhone || null,
      email: addEmail || null,
      address: addAddress || null,
      status: addStatus,
      assigned_to: assignedRepId
    };

    try {
      if (isOnline()) {
        const { data: newCustomer, error } = await supabase
          .from("customers")
          .insert([payload])
          .select()
          .single();

        if (error) throw error;

        // ✅ إصلاح: إضافة العميل الجديد مباشرة للقائمة المحلية بدل عمل تحميل كامل للصفحة يشبه الـ Reload
        if (newCustomer) {
          setCustomersList(prev => [newCustomer, ...prev]);
        }

        if (newCustomer && leadDraft) {
          await applyLeadDraft(newCustomer, leadDraft);
        }

        if (assignedRepId && assignedRepId !== currentUserId) {
          await supabase.from("notifications").insert({
            title: "توزيع وإسناد عملاء جدد",
            message: `📈 تم إسناد العميل الجديد (${addName}) لمتابعتك الفورية من قبل مدير المبيعات.`,
            type: "sales",
            link: "/CRM"
          });
        }

        alert("✅ تم تسجيل وإسناد العميل الجديد وتحديث الـ CRM بنجاح!");
      } else {
        addToOfflineQueue("customers", "INSERT", payload);
        alert("⚠️ تم حفظ العميل محلياً مؤقتاً لعدم وجود إنترنت؛ وسيتم توزيعه ومزامنته تلقائياً فور عودة الشبكة.");
      }

      setIsAddCustomerOpen(false);
      setAddName("");
      setAddMobile("");
      setAddPhone("");
      setAddEmail("");
      setAddAddress("");
      setAddAssignedTo("");
      setAddStatus("جديد");

    } catch (err: any) {
      alert("حدث خطأ أثناء تسجيل العميل: " + err.message);
    } finally {
      setSaving(false);
    }
  }

  async function advanceWorkflowStage(projectId: string, newStage: string, notifyRole: string, message: string) {
    try {
      setSaving(true);
      const { error: stageError } = await supabase
        .from("projects")
        .update({ workflow_stage: newStage })
        .eq("id", projectId);
      if (stageError) throw stageError;

      let customerStatus = "";
      if (newStage === "needs_estimate") {
        customerStatus = "قيد انتظار التسعير";
      } else if (newStage === "initial_ready") {
        customerStatus = "تم إصدار المقايسة";
      } else if (newStage === "amendments_requested") {
        customerStatus = "متابعة مستمرة";
      } else if (newStage === "final") {
        customerStatus = "تم التعاقد";
      }

      if (customerStatus && crmData.customer?.customerCode) {
        const { data: custData } = await supabase
          .from("customers")
          .select("id")
          .eq("customer_code", crmData.customer.customerCode)
          .single();

        if (custData) {
          const { error: custError } = await supabase
            .from("customers")
            .update({ status: customerStatus })
            .eq("id", custData.id);
          if (custError) throw custError;

          // مزامنة القائمة الحية للمبيعات حياً لعدم ضياع التعديلات
          setCustomersList(prev => prev.map(c => c.id === custData.id ? { ...c, status: customerStatus } : c));
        }
      }

      const { error: notifyError } = await supabase
        .from("notifications")
        .insert({
          title: "تحديث مرحلة العمل",
          message,
          type: notifyRole === "engineer" ? "engineer_task" : "sales",
          target_role: notifyRole,
          project_id: projectId
        });
      if (notifyError) console.error("تعذر إرسال الإشعار:", notifyError.message);

      setCRMData((prev: any) => ({
        ...prev,
        customer: {
          ...prev.customer,
          status: customerStatus || prev.customer.status
        },
        project: { ...prev.project, workflow_stage: newStage }
      }));

      // تحديث قائمة المشاريع المحلية فورياً
      setProjectsList(prev => prev.map(p => p.id === projectId ? { ...p, workflow_stage: newStage } : p));

      // ✅ إصلاح: كان بيستدعي loadAllCRMData() هنا، وده بيعمل شاشة تحميل كاملة بتخفي كل
      // تفاصيل المشروع المفتوح مؤقتاً (زي ما الصفحة اتعملها ريفريش)، رغم إن التحديث المحلي
      // فوق (setCRMData / setProjectsList) كافي تماماً وبيعكس التغيير فوراً من غير أي قطع بصري.
    } catch (err: any) {
      console.error("خطأ في تحديث مرحلة سير العمل والعميل الموحد:", err);
      alert("حدث خطأ أثناء تحديث حالة المقايسة: " + err.message);
    } finally {
      setSaving(false);
    }
  }

  // حفظ بيانات المشروع ومزامنة المتصفح سحابياً باللحظة دون سقوط البيانات
  async function handleSaveProject() {
    if (!crmData.customer?.customerCode) {
      alert("يرجى تحديد واختيار عميل من الجدول بالأعلى أولاً لتأسيس المشروع له.");
      return;
    }

    // ✅ إصلاح: كانت كل الحقول دي (رغم علامة * الإلزامية فى الواجهة) بتتسجل فاضية أو بصفر
    // بصمت من غير أي تحذير — وده خطير لأن المساحة تحديداً أساس لحسابات تانية كتير
    // (الجدول الزمني، تقدير الميزانية، وغيرها). دلوقتي لازم تتملى فعلياً قبل الحفظ.
    const missingFields: string[] = [];
    if (!crmData.customer?.mobile?.trim()) missingFields.push("رقم الموبايل");
    if (!crmData.project?.unitType?.trim()) missingFields.push("نوع الوحدة");
    if (!crmData.project?.unitAddress?.trim()) missingFields.push("موقع وعنوان الوحدة بالتفصيل");
    if (!Number(crmData.project?.area)) missingFields.push("المساحة الإجمالية (م²)");
    if (!Number(crmData.project?.contractValue)) missingFields.push("إجمالي القيمة المالية للعقد (ج.م)");

    if (missingFields.length > 0) {
      alert(`⚠️ يرجى تعبئة الحقول الإلزامية الآتية قبل الحفظ:\n\n${missingFields.map((f) => `• ${f}`).join("\n")}`);
      return;
    }

    setSaving(true);
    try {
      const { data: custData } = await supabase
        .from("customers")
        .select("id")
        .eq("customer_code", crmData.customer.customerCode)
        .single();

      if (!custData) throw new Error("فشل العثور على معرّف العميل المستهدف بالسحابة.");

      const generatedProjCode = crmData.project?.projectCode || await generateSequentialCode("projects", "project_code", "P");
      const generatedEstNum = crmData.project?.estimateNumber || await generateSequentialCode("projects", "estimate_number", "EST");

      const payload = {
        customer_id: custData.id,
        project_name: crmData.project?.projectName || `مشروع العميل ${crmData.customer.name}`,
        project_code: generatedProjCode,
        location: crmData.project?.location || "",
        unit_type: crmData.project?.unitType || "شقة",
        area: Number(crmData.project?.area || 0),
        finishing_level: crmData.project?.finishingLevel || "اقتصادى (لوكس)",
        unit_status: crmData.project?.unitStatus || "معلق / قيد الانتظار",
        unit_address: crmData.project?.unitAddress || "",
        estimate_date: crmData.project?.estimateDate || null,
        receptions_count: Number(crmData.project?.receptionsCount || 1),
        rooms_count: Number(crmData.project?.roomsCount || 2),
        bathrooms_count: Number(crmData.project?.bathroomsCount || 1),
        kitchens_count: Number(crmData.project?.kitchensCount || 1),
        balconies_count: Number(crmData.project?.balconiesCount || 1),
        living_count: Number(crmData.project?.livingCount || 1),
        corridors_count: Number(crmData.project?.corridorsCount || 0),
        garden_exist: !!crmData.project?.gardenExist,
        garden_area: Number(crmData.project?.gardenArea || 0),
        contract_value: Number(crmData.project?.contractValue || 0) 
      };

      if (isOnline()) {
        let error = null;

        if (crmData.project?.id && !crmData.project.id.startsWith("d19b7d8d") && !crmData.project.id.startsWith("new")) {
          const { error: updateErr } = await supabase
            .from("projects")
            .update(payload)
            .eq("id", crmData.project.id);
          error = updateErr;

          if (!error) {
            // تحديث قائمة المشاريع المحلية فورياً
            setProjectsList(prev => prev.map(p => p.id === crmData.project.id ? {
              ...p,
              project_name: payload.project_name,
              unit_type: payload.unit_type,
              area: payload.area,
              finishing_level: payload.finishing_level,
              unit_status: payload.unit_status,
              unit_address: payload.unit_address,
              estimate_date: payload.estimate_date,
              contract_value: payload.contract_value 
            } : p));
          }
        } else {
          const projectPayload = {
            ...payload,
            workflow_stage: "pending_specs" 
          };
          const { data: newProj, error: insertErr } = await supabase
            .from("projects")
            .insert([projectPayload])
            .select("id")
            .single();
          
          error = insertErr;

          if (newProj && !error) {
            const activeProjId = (newProj as any).id;

            setCRMData((prev: any) => ({
              ...prev,
              project: {
                ...prev.project,
                id: activeProjId,
                projectCode: generatedProjCode,
                estimateNumber: generatedEstNum,
                workflow_stage: "pending_specs" 
              }
            }));

            const { data: updatedProjs, error: projsError } = await supabase
              .from("projects")
              .select("*")
              .eq("customer_id", custData.id);

            if (!projsError && updatedProjs) {
              setSelectedCustomerProjects(updatedProjs);
            }
          }
        }

        if (error) throw error;
        alert("✅ تم حفظ وتأمين مواصفات وميزانية المشروع بنجاح!");
      } else {
        const offlinePayload = {
          ...payload,
          id: crmData.project?.id || null
        };
        addToOfflineQueue("projects", crmData.project?.id ? "UPDATE" : "INSERT", offlinePayload);
        alert("⚠️ تم حفظ ميزانية المشروع محلياً مؤقتاً؛ سيتم مزامنتها تلقائياً فور توفر الإنترنت.");
      }

    } catch (err: any) {
      console.error("Save Project Error:", err);
      alert("حدث خطأ أثناء حفظ المشروع: " + err.message);
    } finally {
      setSaving(false);
    }
  }

  useEffect(() => {
    if (!crmData.customer?.customerCode) return;
    loadCustomerTimelineLogs();
    setVisibleLogsCount(5); 
  }, [crmData.customer?.customerCode]);

  async function loadCustomerTimelineLogs() {
    setLoadingLogs(true);
    try {
      const { data: custData } = await supabase
        .from("customers")
        .select("id")
        .eq("customer_code", crmData.customer.customerCode)
        .single();

      if (custData) {
        const { data: logs, error } = await supabase
          .from("customer_logs")
          .select("*")
          .eq("customer_id", custData.id)
          .order("created_at", { ascending: false });

        if (error) throw error;
        setCustomerLogs(logs || []);
      }
    } catch (e) {
      console.error("Error loading timeline logs:", e);
    } finally {
      setLoadingLogs(false);
    }
  }

  async function handleSelectCustomerFromGrid(customer: any) {
    try {
      const { data: projs, error } = await supabase
        .from("projects")
        .select("*")
        .eq("customer_id", customer.id);

      if (error) throw error;

      const customerProjectsList = projs || [];
      setSelectedCustomerProjects(customerProjectsList);

      const activeProject = customerProjectsList.length > 0 ? customerProjectsList[0] : null;

      // 🌟 كتلة المعالجة الذاتية والمزامنة التلقائية لبيانات ليد الإعلانات (Self-Healing Data Sync)
      let resolvedArea = activeProject ? Number(activeProject.area || 0) : 0;
      let resolvedAddress = activeProject ? (activeProject.unit_address || "") : "";
      let resolvedLocation = activeProject ? (activeProject.location || "") : "";
      let resolvedFinishing = activeProject ? (activeProject.finishing_level || "اقتصادى (لوكس)") : "اقتصادى (لوكس)";
      let resolvedContractValue = activeProject ? Number(activeProject.contract_value || 0) : 0;
      let resolvedWorkflow = activeProject ? (activeProject.workflow_stage || "pending_specs") : "pending_specs";

      // إذا كانت البيانات الميدانية بالمشروع صفرية أو فارغة، نقوم بسحبها حياً من طلبات الحاسبة السابقة
      if (resolvedArea === 0 || !resolvedAddress) {
        const { data: reqData } = await supabase
          .from("customer_requests")
          .select("area, region, finishing_level, estimatedMin")
          .eq("phone", String(customer.mobile).trim())
          .order("created_at", { ascending: false }) // استرجاع الأحدث دائماً
          .limit(1);

        if (reqData && reqData.length > 0) {
          const req = reqData[0];
          if (resolvedArea === 0) resolvedArea = Number(req.area || 0);
          if (!resolvedAddress) resolvedAddress = req.region || "";
          if (!resolvedLocation) resolvedLocation = req.region || "";
          if (resolvedFinishing === "اقتصادى (لوكس)" && req.finishing_level) {
            // توحيد مصطلحات التشطيب لتتناسب مع خيارات المنسدل بالـ ERP
            const level = String(req.finishing_level).trim();
            if (level.includes("ألترا") || level.includes("فاخر")) {
              resolvedFinishing = "فاخر (الترا لوكس)";
            } else if (level.includes("سوبر")) {
              resolvedFinishing = "متوسط (سوبر لوكس )";
            } else {
              resolvedFinishing = "اقتصادى (لوكس)";
            }
          }
          if (resolvedContractValue === 0) resolvedContractValue = Number(req.estimatedMin || 0);
        }
      }

      setCRMData((prev: any) => ({
        ...prev,
        customer: {
          name: customer.name,
          mobile: customer.mobile,
          customerCode: customer.customer_code,
          phone: customer.phone || "",
          address: customer.address || "",
          email: customer.email || "",
          status: customer.status,
          created_at: customer.created_at
        },
        project: activeProject ? {
          id: activeProject.id,
          projectName: activeProject.project_name,
          projectCode: activeProject.project_code,
          location: resolvedLocation,
          unitType: activeProject.unit_type,
          unitStatus: activeProject.unit_status,
          unitAddress: resolvedAddress,
          estimateDate: activeProject.estimate_date,
          finishingLevel: resolvedFinishing,
          area: resolvedArea,
          planUrl: activeProject.plan_url,
          workflow_stage: resolvedWorkflow,
          receptionsCount: Number(activeProject.receptions_count || 1),
          roomsCount: Number(activeProject.rooms_count || 2),
          bathroomsCount: Number(activeProject.bathrooms_count || 1),
          kitchensCount: Number(activeProject.kitchens_count || 1),
          balconiesCount: Number(activeProject.balconies_count || 1),
          livingCount: Number(activeProject.living_count || 1),
          corridorsCount: Number(activeProject.corridors_count || 0),
          gardenExist: !!activeProject.garden_exist,
          gardenArea: Number(activeProject.garden_area || 0),
          contractValue: resolvedContractValue 
        } : {
          // تهيئة مشروع افتراضي فارغ ومزامنته حياً مع ليد الحاسبة
          // ✅ إصلاح: كان فيه كود مشروع عشوائي هنا (P-xxxx) بيتسجل فى المسودة ويتاخد كـ"نهائي" وقت
          // الحفظ الفعلي بسبب "crmData.project?.projectCode || generateSequentialCode(...)"، فيتخطى
          // التوليد التسلسلي الصحيح تماماً. حذفناه عشان دايماً يتولد كود تسلسلي حقيقي وقت الحفظ.
          id: "new-" + Date.now(),
          projectName: `مشروع العميل ${customer.name}`,
          location: resolvedLocation || "",
          unitType: "شقة",
          unitStatus: "بدون تشطيب (طوب احمر)",
          unitAddress: resolvedAddress || "",
          estimateDate: "",
          finishingLevel: resolvedFinishing || "اقتصادى (لوكس)",
          area: resolvedArea || 0,
          workflow_stage: "pending_specs",
          receptionsCount: 1,
          roomsCount: 2,
          bathroomsCount: 1,
          kitchensCount: 1,
          balconiesCount: 1,
          livingCount: 1,
          corridorsCount: 0,
          gardenExist: false,
          gardenArea: 0,
          contractValue: resolvedContractValue || 0
        },
        estimate: {
          number: "EST-0001",
          date: "",
          status: "مبدئية",
          convertedFromInitial: false,
          materialsCost: 0,
          laborCost: 0,
          engineeringPercentage: 15,
          engineeringValue: 0,
          total: 0,
          items: []
        },
        finishing: JSON.parse(JSON.stringify(DEFAULT_FINISHING_SCHEMA))
      }));

      // سحب تفاصيل البنود والأسعار حيوياً من قاعدة البيانات بعد التزامن
      const resolvedProjId = activeProject ? activeProject.id : null;
      if (resolvedProjId) {
        await loadProjectData(resolvedProjId);
      }
    } catch (err) {
      console.error("Error selecting customer from grid:", err);
    }
  }

  async function handleSwitchActiveProject(projectId: string) {
    const selectedProj = selectedCustomerProjects.find(p => p.id === projectId);
    if (!selectedProj) return;

    setSaving(true);
    try {
      setCRMData((prev: any) => ({
        ...prev,
        project: {
          id: selectedProj.id,
          projectName: selectedProj.project_name,
          projectCode: selectedProj.project_code,
          location: selectedProj.location,
          unitType: selectedProj.unit_type,
          unitStatus: selectedProj.unit_status,
          unitAddress: selectedProj.unit_address,
          estimateDate: selectedProj.estimate_date,
          finishingLevel: selectedProj.finishing_level,
          area: selectedProj.area,
          planUrl: selectedProj.plan_url,
          workflow_stage: selectedProj.workflow_stage || "pending_specs",
          receptionsCount: Number(selectedProj.receptions_count || 1),
          roomsCount: Number(selectedProj.rooms_count || 2),
          bathroomsCount: Number(selectedProj.bathrooms_count || 1),
          kitchensCount: Number(selectedProj.kitchens_count || 1),
          balconiesCount: Number(selectedProj.balconies_count || 1),
          livingCount: Number(selectedProj.living_count || 1),
          corridorsCount: Number(selectedProj.corridors_count || 0),
          gardenExist: !!selectedProj.garden_exist,
          gardenArea: Number(selectedProj.garden_area || 0),
          contractValue: Number(selectedProj.contract_value || 0) 
        },
        estimate: {
          number: "EST-0001",
          date: "",
          status: "مبدئية",
          convertedFromInitial: false,
          materialsCost: 0,
          laborCost: 0,
          engineeringPercentage: 15,
          engineeringValue: 0,
          total: 0,
          items: []
        },
        finishing: JSON.parse(JSON.stringify(DEFAULT_FINISHING_SCHEMA))
      }));

      await loadProjectData(selectedProj.id);
    } catch (err) {
      console.error("Error switching active project:", err);
    } finally {
      setSaving(false);
    }
  }

  async function handleSaveFollowUp() {
    if (!followUpFeedback) {
      alert("الرجاء إدخال تفاصيل المتابعة والمكالمة أولاً.");
      return;
    }

    setSaving(true);
    try {
      const { data: { user } } = await supabase.auth.getUser();

      const { data: custData } = await supabase
        .from("customers")
        .select("id")
        .eq("customer_code", crmData.customer.customerCode)
        .single();

      if (!custData) throw new Error("فشل العثور على معرّف العميل بقاعدة البيانات.");

      const directStatusText = `[حالة العميل الموثقة: ${crmData.customer.status || "جديد"}] - ${followUpFeedback}`;

      const payload = {
        customer_id: custData.id,
        sales_rep_id: user?.id || null,
        interaction_type: followUpType,
        feedback: directStatusText,
        next_follow_up_date: followUpNextDate || null
      };

      if (isOnline()) {
        const { error: logError } = await supabase
          .from("customer_logs")
          .insert([payload]);

        if (logError) throw logError;

        const { error: custUpdateError } = await supabase
          .from("customers")
          .update({ status: "متابعة مستمرة" })
          .eq("id", custData.id);

        if (custUpdateError) throw custUpdateError;

        alert("✅ تم حفظ المتابعة التاريخية بنجاح وتحديث حالة العميل بالسيستم!");
      } else {
        addToOfflineQueue("customer_logs", "INSERT", payload);
        alert("⚠️ تم حفظ المتابعة محلياً؛ سيتم المزامنة وتغيير حالة العميل فور توفر الشبكة.");
      }

      setIsFollowUpOpen(false);
      setFollowUpFeedback("");
      setFollowUpNextDate("");
      
      await Promise.all([
        loadAllCRMData(),
        loadCustomerTimelineLogs()
      ]);

    } catch (err: any) {
      alert("حدث خطأ أثناء حفظ المتابعة: " + err.message);
    } finally {
      setSaving(false);
    }
  }

  function setQuickFollowUpDate(days: number) {
    const targetDate = new Date();
    targetDate.setDate(targetDate.getDate() + days);
    const yyyy = targetDate.getFullYear();
    const mm = String(targetDate.getMonth() + 1).padStart(2, "0");
    const dd = String(targetDate.getDate()).padStart(2, "0");
    setFollowUpNextDate(`${yyyy}-${mm}-${dd}`);
  }

  const getNormalizedStatus = (status: string) => {
    const s = String(status || "").trim();
    if (s === "جديد" || s === "new") return "جديد";
    if (s === "متابعة" || s === "متابعة مستمرة" || s === "تم إصدار المقايسة" || s === "follow_up") return "متابعة";
    if (s === "تم التعاقد" || s === "contracted") return "تم التعاقد";
    if (s === "مؤجل" || s === "postponed") return "مؤجل";
    if (s === "ملغي" || s === "cancelled" || s === "closed") return "ملغي";
    return "جديد";
  };

  const baseFilteredCustomers = customersList.filter((c: any) => {
    if (isManager && selectedSalesFilter !== "all") {
      return c.assigned_to === selectedSalesFilter;
    }
    return true;
  });

  const countAll = baseFilteredCustomers.length;
  const countNew = baseFilteredCustomers.filter((c: any) => getNormalizedStatus(c.status) === "جديد").length;
  const countFollow = baseFilteredCustomers.filter((c: any) => getNormalizedStatus(c.status) === "متابعة").length;
  const countContracted = baseFilteredCustomers.filter((c: any) => getNormalizedStatus(c.status) === "تم التعاقد").length;
  const countInProgress = projectsList.filter((p: any) => p.status === "active").length;
  const countPostponed = baseFilteredCustomers.filter((c: any) => getNormalizedStatus(c.status) === "مؤجل").length;
  const countCancelled = baseFilteredCustomers.filter((c: any) => getNormalizedStatus(c.status) === "ملغي").length;
  const countNeedsEstimate = projectsList.filter((p: any) => p.workflow_stage === "needs_estimate").length;

  const cards = [
    { id: "all", name: "كل العملاء", count: countAll, icon: "👥" },
    { id: "needs_estimate", name: "بانتظار التسعير", count: countNeedsEstimate, icon: "⏳" },
    { id: "جديد", name: "العملاء الجدد", count: countNew, icon: "✨" },
    { id: "متابعة", name: "متابعة مستمرة", count: countFollow, icon: "📞" },
    { id: "تم التعاقد", name: "تم التعاقد", count: countContracted, icon: "✍️" },
    { id: "active", name: "جاري التنفيذ", count: countInProgress, icon: "🏗️" },
    { id: "مؤجل", name: "مؤقت مؤجل", count: countPostponed, icon: "⏳" },
    { id: "ملغي", name: "ملغي / مغلق", count: countCancelled, icon: "✕" }
  ];

  const filteredCustomers = baseFilteredCustomers.filter((c: any) => {
    if (selectedStatus === "all") return true;

    const customerIdClean = String(c.id || "").trim().toLowerCase();

    if (selectedStatus === "active") {
      return projectsList.some((p: any) => {
        const projectCustIdClean = String(p.customer_id || "").trim().toLowerCase();
        return projectCustIdClean === customerIdClean && p.status === "active";
      });
    }

    if (selectedStatus === "needs_estimate") {
      return projectsList.some((p: any) => {
        const projectCustIdClean = String(p.customer_id || "").trim().toLowerCase();
        return projectCustIdClean === customerIdClean && p.workflow_stage === "needs_estimate";
      });
    }

    return getNormalizedStatus(c.status) === selectedStatus;
  });

  const isProjectSelected = !!crmData.customer?.name;

  // جلب رقم الخطوة النشطة لعرض البار الذهبي المتوهج
  const currentActiveStageIndex = getCurrentStageIndex(crmData.project?.workflow_stage);

  return (
    <main className="min-h-screen bg-[#020B1C] relative overflow-hidden font-alexandria" dir="rtl">
      
      {/* 🛠️ جدار الحماية البصري الموحد وتنسيق شريط التمرير المذهب وحظر التداخل بـ whitespace-nowrap و min-w-[850px] بالجدول لمنع القص والتقاطع كلياً */}
      <style dangerouslySetInnerHTML={{__html: `
        /* تفعيل وإظهار شريط التمرير الأفقي والرأسي بكافة الجداول بألوان ذهبية فاخرة */
        ::-webkit-scrollbar { 
          width: 6px !important; 
          height: 6px !important; 
          display: block !important;
        }
        ::-webkit-scrollbar-track { 
          background: #020B1C !important; 
        }
        ::-webkit-scrollbar-thumb { 
          background: #D4AF37 !important; 
          border-radius: 9999px !important; 
        }
        ::-webkit-scrollbar-thumb:hover { 
          background: #AA7C11 !important; 
        }

        /* إلغاء أكواد الإخفاء لضمان انسيابية التمرير بالماوس والجوال */
        .overflow-x-auto { 
         
          -ms-overflow-style: auto !important; 
          overflow-x: auto !important; 
        }

        /* عزل تلوين وأوزان خلايا جدول الـ CRM ومنع تسريب الـ CSS للسايدبار */
        .premium-crm-table thead th {
          font-size: 0.75rem !important;
          font-weight: 500 !important;
          color: #D4AF37 !important;
          text-align: right !important;
          background-color: #020B1C !important;
          border-bottom: 2px solid rgba(212, 175, 55, 0.3) !important;
          padding: 14px 16px !important;
          letter-spacing: normal !important;
        }

        .premium-crm-table tbody td {
          font-size: 0.8rem !important;
          font-weight: 400 !important;
         
          text-align: right !important;
          border-bottom: 1px solid rgba(212, 175, 55, 0.1) !important;
          padding: 14px 16px !important;
          letter-spacing: normal !important;
        }

        .premium-crm-table tbody tr:hover {
          background-color: rgba(7, 19, 42, 0.8) !important;
        }
      `}} />

      <Sidebar />
      <section className="flex-1 flex flex-col lg:pr-sidebar m-0">
        <Header />
        
        <div className="p-4 md:p-8 space-y-6 text-right">
          <div className="flex justify-between items-center border-b border-[#D4AF37]/20 pb-5 select-none">
            <div>
              <h1 className="text-xl md:text-2xl font-black text-[#D4AF37] flex items-center gap-2.5">
                <span>بيانات العملاء والمشاريع والـ CRM</span>
                <span className="w-2.5 h-2.5 rounded-full bg-[#D4AF37] animate-ping" />
              </h1>
              <p className="text-white text-xs mt-2">فرز فوري لتدفق صفقات المبيعات، ومزامنة مرحلة التشطيبات والمواصفات الميدانية.</p>
            </div>
          </div>

          {isSearchOpen && (
            <div className="fixed inset-0 bg-black/85 backdrop-blur-md z-50 flex items-center justify-center p-4 animate-fade-in select-none">
              <div className="bg-[#07132a] border-2 border-[#D4AF37] rounded-4xl p-6 md:p-8 w-full max-w-4xl shadow-2xl relative space-y-4">
                <div className="flex justify-between items-center border-b border-[#243556] pb-3 mb-4 select-none">
                  <h3 className="text-[#D4AF37] font-bold text-lg flex items-center gap-1.5">
                    📂 أداة البحث الموحد للمشاريع والعملاء
                  </h3>
                  <button 
                    type="button" 
                    onClick={(e) => { e.preventDefault(); setIsSearchOpen(false); }}
                    className="text-gray-400 hover:text-rose-500 font-bold text-sm cursor-pointer transition"
                  >
                    ✕ 
                  </button>
                </div>
                <CRMSearch onClose={() => setIsSearchOpen(false)} />
              </div>
            </div>
          )}

          {isAddCustomerOpen && (
            <div className="fixed inset-0 bg-black/85 backdrop-blur-md z-50 flex items-center justify-center p-4 animate-fade-in select-none">
              <div className="bg-[#07132a] border-2 border-[#D4AF37] rounded-4xl p-6 md:p-8 w-full max-w-lg shadow-2xl relative space-y-4 text-right text-white">
                <div className="flex justify-between items-center border-b border-[#243556] pb-3 mb-4">
                  <h3 className="text-[#D4AF37] font-bold text-lg flex items-center gap-1.5">
                    ➕ نموذج إضافة عميل جديد للـ CRM
                  </h3>
                  <button 
                    type="button" 
                    onClick={(e) => { e.preventDefault(); closeAddCustomer(); }}
                    className="text-gray-400 hover:text-rose-500 font-bold text-sm cursor-pointer transition"
                  >
                    ✕
                  </button>
                </div>

                {leadDraft && (
                  <div className="bg-[#D4AF37]/10 border border-[#D4AF37]/40 rounded-2xl p-3 text-[11px] font-bold text-[#F0E6D2] leading-relaxed">
                    🤖 تقدير مبدئي من مساعد المبيعات: شقة {leadDraft.area} م²
                    {leadDraft.levelSpecified ? ` - ${leadDraft.levelLabel}` : " - المستوى لم يُحدد"}
                    {leadDraft.minCost && leadDraft.maxCost
                      ? ` | ${Number(leadDraft.minCost).toLocaleString("en-US")} - ${Number(leadDraft.maxCost).toLocaleString("en-US")} جنيه`
                      : ""}
                    {leadDraft.minDays && leadDraft.maxDays ? ` | ${leadDraft.minDays} - ${leadDraft.maxDays} يوم` : ""}
                    <br />
                    أدخل الاسم والموبايل الحقيقيين للعميل، وسيُنقل هذا التقدير لمشروعه تلقائياً بعد التسجيل.
                  </div>
                )}

                <div className="space-y-4 text-sm font-semibold">
                  <div>
                    <label className="block text-[#D4AF37] font-bold px-3 text-[12px] mb-1.5">اسم العميل *</label>
                    <input
                      type="text"
                      placeholder="الاسم الثلاثي للعميل"
                      value={addName}
                      onChange={(e) => setAddName(e.target.value)}
                      className="w-full h-11 rounded-xl bg-[#020B1C] border border-[#D4AF37]/20 text-[#F0E6D2] px-3.5 outline-none focus:border-[#D4AF37] text-xs font-medium"
                    />
                  </div>
 <div className="grid grid-cols-2 gap-4">
 <div>
                      <label className="block text-[#D4AF37] font-bold px-3 text-[12px]  mb-1.5 whitespace-nowrap">رقم الموبايل  *</label>
                      <input
                        type="text"
                        placeholder="010xxxxxxxx"
                        value={addMobile}
                        onChange={(e) => setAddMobile(e.target.value)}
                        className="w-full h-11 rounded-xl bg-[#020B1C] border border-[#D4AF37]/20 text-[#F0E6D2] px-3.5 outline-none font-mono focus:border-[#D4AF37] text-xs font-medium"
                      />
                    </div>

                 
                    <div>
                      <label className="block text-[#D4AF37] font-bold px-3 text-[12px]  mb-1.5 whitespace-nowrap">رقم موبايل اخر (اختياري)</label>
                      <input
                        type="text"
                        placeholder="رقم موبايل اخر "
                        value={addPhone}
                        onChange={(e) => setAddPhone(e.target.value)}
                        className="w-full h-11 rounded-xl bg-[#020B1C] border border-[#D4AF37]/20 text-[#F0E6D2] px-3.5 outline-none font-mono focus:border-[#D4AF37] text-xs font-medium"
                      />
                    </div>
                   
                  </div>

                  <div>
                    <label className="block text-[#D4AF37] font-bold px-3 text-[12px]  mb-1.5">العنوان بالتفصيل</label>
                    <input
                      type="text"
                      placeholder="مثال: التجمع الخامس - النرجس"
                      value={addAddress}
                      onChange={(e) => setAddAddress(e.target.value)}
                      className="w-full h-11 rounded-xl bg-[#020B1C] border border-[#D4AF37]/20 text-[#F0E6D2] px-3.5 outline-none focus:border-[#D4AF37] text-xs font-medium"
                    />
                  </div>

                  <div>
                    <label className="block text-[#D4AF37] font-bold px-3 text-[12px]  mb-1.5">البريد الإلكتروني للعميل</label>
                    <input
                      type="email"
                      placeholder="email@example.com"
                      value={addEmail}
                      onChange={(e) => setAddEmail(e.target.value)}
                      className="w-full h-11 rounded-xl bg-[#020B1C] border border-[#D4AF37]/20 text-[#F0E6D2] px-3.5 outline-none font-mono focus:border-[#D4AF37] text-xs font-medium"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-[#D4AF37] font-bold px-3 text-[12px] mb-1.5 whitespace-nowrap">توزيع وإسناد العميل</label>
                      {isManager ? (
                        <select
                          value={addAssignedTo}
                          onChange={(e) => setAddAssignedTo(e.target.value)}
                          className="w-full h-11 rounded-xl bg-[#020B1C] border border-[#D4AF37]/20 text-[#D4AF37] font-bold px-3 outline-none cursor-pointer text-xs focus:border-[#D4AF37]"
                        >
                          <option value="">-- عام (بدون موظف محدد) --</option>
                          {salesStaff.map(staff => (
                            <option key={staff.id} value={staff.id}>{staff.name}</option>
                          ))}
                        </select>
                      ) : (
                        <input
                          type="text"
                          value="إسناد تلقائي لحسابك الشخصي"
                          disabled
                          className="w-full h-11 rounded-xl bg-[#020B1C] border border-[#243556] text-gray-500 px-3 outline-none text-center font-bold text-xs"
                        />
                      )}
                    </div>
                    <div>
                      <label className="block text-[#D4AF37] font-bold px-3 text-[12px]  mb-1.5 whitespace-nowrap">حالة العميل  *</label>
                      <select
                        value={addStatus}
                        onChange={(e) => setAddStatus(e.target.value)}
                        className="w-full h-11 rounded-xl bg-[#020B1C] border border-[#D4AF37]/20 text-[#D4AF37] font-bold px-3 outline-none cursor-pointer text-xs focus:border-[#D4AF37]"
                      >
                        <option value="جديد">جديد</option>
                        <option value="متابعة مستمرة">متابعة مستمرة</option>
                      </select>
                    </div>
                  </div>
                </div>

                <div className="flex justify-end gap-3 pt-4 border-t border-[#243556]">
                  {/* 🌟 تحديث وإعادة هيكلة زرار إضافة العميل للدستور البصري الحركي */}
                  <button
                    type="button" 
                    onClick={(e) => { e.preventDefault(); handleInsertNewCustomer(); }}
                    disabled={saving}
                    className="px-6 h-11 rounded-xl bg-linear-to-b from-[#0c1e3d] to-[#040e20] text-[#D4AF37] border-2 border-[#D4AF37] shadow-[0_0_20px_rgba(212,175,55,0.25)] hover:shadow-[0_0_30px_rgba(212,175,55,0.45)] hover:scale-[1.03] active:scale-95 transition-all duration-300 cursor-pointer text-xs font-black flex items-center justify-center gap-1.5 select-none relative overflow-hidden disabled:opacity-50"
                  >
                    {saving ? "جاري الحفظ..." : "💾 تسجيل العميل بالـ CRM"}
                    <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-linear-to-r from-transparent via-[#D4AF37] to-transparent shadow-[0_-1px_6px_rgba(212,175,55,0.8)]" />
                  </button>
                </div>
              </div>
            </div>
          )}

          {isManager && (
            <div className="bg-[#07132a] border border-[#D4AF37]/20 p-4 rounded-4xl flex items-center gap-3">
              <label className="text-gray-300 text-sm whitespace-nowrap">تصفية بحسب مسؤول المبيعات:</label>
              <select
                value={selectedSalesFilter}
                onChange={(e) => setSelectedSalesFilter(e.target.value)}
                className="bg-[#020B1C] border border-[#D4AF37]/20 text-[#D4AF37] rounded-xl text-sm p-2.5 outline-none cursor-pointer focus:border-[#D4AF37]"
              >
                <option value="all">رؤية كافة موظفين المبيعات (الكل)</option>
                {salesStaff.map(staff => (
                  <option key={staff.id} value={staff.id}>{staff.name}</option>
                ))}
              </select>
            </div>
          )}

          {loading ? (
            <div className="space-y-6">
              <div className="grid grid-cols-2 md:grid-cols-4 xl:grid-cols-8 gap-4 select-none">
                {[...Array(8)].map((_, i) => (
                  <div key={i} className="p-4 rounded-2xl bg-[#07132a]/60 border border-[#D4AF37]/15 h-28 flex flex-col justify-between animate-pulse">
                    <div className="w-8 h-8 bg-[#020B1C] rounded-lg" />
                    <div className="space-y-2 mt-3">
                      <div className="h-3 w-16 bg-[#020B1C] rounded" />
                      <div className="h-5 w-10 bg-[#020B1C] rounded" />
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ) : (
            <>
              <div className="grid grid-cols-2 md:grid-cols-4 xl:grid-cols-8 gap-4 select-none">
                {cards.map((card) => {
                  const isCurrent = selectedStatus === card.id;
                  return (
                    <div
                      key={card.id}
                      onClick={() => setSelectedStatus(card.id)}
                      className={`p-4 rounded-2xl bg-[#07132a] border transition-all duration-300 transform hover:translate-y-1 hover:shadow-2xl flex flex-col justify-between cursor-pointer select-none ${
                        isCurrent 
                          ? "border-[#D4AF37] shadow-[0_0_15px_rgba(212,175,55,0.25)] bg-[#0b1b3d]" 
                          : "border-[#D4AF37]/15 hover:border-[#D4AF37]/45"
                      }`}
                    >
                      <div className="flex justify-between items-center w-full">
                        <span className="text-2xl select-none">{card.icon}</span>
                        <span className="text-white text-xl font-extrabold font-mono tracking-tight">
                          {card.count.toLocaleString('en-US')}
                        </span>
                      </div>
                      <div className="mt-3 text-right">
                        <p className="text-[#D4AF37] text-xs font-black whitespace-nowrap">{card.name}</p>
                      </div>
                    </div>
                  );
                })}
              </div>

              <div className="bg-[#07132a] border-2 border-[#D4AF37]/50 rounded-4xl overflow-hidden shadow-2xl transition duration-300">
                <div className="p-4 border-b border-[#D4AF37] bg-[#0b1b3d] flex justify-between items-center select-none">
                  <h3 className="text-[#D4AF37] text-md md:text-md font-bold">
                    نتائج التصفية والفرز الجاري للعملاء والمبيعات ({filteredCustomers.length})
                  </h3>

                  <div className="flex items-center gap-3">
                    <button
                      type="button"
                      onClick={() => setIsAddCustomerOpen(true)}
                      className="w-11 h-11 rounded-xl bg-black/60 border-2 border-[#D4AF37] text-[#D4AF37] hover:bg-[#D4AF37] hover:text-[#020B1C] flex items-center justify-center cursor-pointer transition-all duration-300 hover:translate-y-0.5 shadow-[0_0_10px_rgba(212,175,55,0.15)] hover:shadow-[0_0_20px_rgba(212,175,55,0.45)] shrink-0"
                      title="تسجيل عميل جديد بالـ CRM"
                    >
                      <UserPlus size={16} strokeWidth={2.2} />
                    </button>

                    <button
                      type="button"
                      onClick={() => setIsSearchOpen(true)}
                      className="w-11 h-11 rounded-xl bg-black/60 border border-emerald-500/50 text-emerald-400 hover:bg-emerald-500 hover:text-black flex items-center justify-center cursor-pointer transition-all duration-300 hover:translate-y-0.5 shadow-[0_0_10px_rgba(16,185,129,0.15)] hover:shadow-[0_0_20px_rgba(16,185,129,0.45)] shrink-0"
                      title="البحث الاستعلام الشامل"
                    >
                      <Search size={16} strokeWidth={2.2} />
                    </button>
                  </div>
                </div>
                
                {/* تفعيل جدار التمرير المذهب وحظر التداخل بـ whitespace-nowrap و min-w-[850px] بالجدول لمنع القص والتقاطع كلياً */}
                <div className="overflow-x-auto max-h-56 overflow-y-auto pr-1">
                  {filteredCustomers.length > 0 ? (
                    <table className="w-full text-right table-auto min-w-212.5 premium-crm-table">
                      <thead>
                        <tr className="whitespace-nowrap select-none">
                          <th>كود العميل</th>
                          <th>اسم العميل </th>
                          <th>رقم الموبايل </th>
                          <th>العنوان بالكامل</th>
                          <th>تاريخ التسجيل</th>
                          <th className="text-center">حالة العميل بالـ CRM</th>
                        </tr>
                      </thead>
                      <tbody>
                        {filteredCustomers.map((c: any) => {
                          const isSelected = crmData.customer?.customerCode === c.customer_code;
                          return (
                            <tr
                              key={c.id}
                              onClick={() => handleSelectCustomerFromGrid(c)}
                              className={`cursor-pointer transition whitespace-nowrap ${
                                isSelected ? "bg-[#0b1b3d]/60 border-r-4 border-r-[#D4AF37] pr-2.5 pl-3" : ""
                              }`}
                            >
                              <td className="font-mono text-[#D4AF37] font-bold">{c.customer_code}</td>
                              <td className="font-mono text-white">{c.name}</td>
                              <td className="font-mono text-white">
                                {userRole === "engineer" ? "📞 [بيانات محجوبة]" : c.mobile}
                              </td>
                              <td className="text-[#D4AF37] font-bold">{c.address || "-"}</td>
                              <td className="font-mono text-white">
                                {c.created_at ? new Date(c.created_at).toLocaleDateString("ar-EG") : "-"}
                              </td>
                              {/* 🌟 تم التحديث وتعديل كود البادج التالف بالـ CRM إلى ألوان ثابتة ومقروءة للدستور البصري الموحد للعملاء */}
                              <td className="text-center">
                                <span className={`px-2.5 py-1 rounded text-[10px] font-black ${
                                  c.status === "تم التعاقد" ? "bg-emerald-500/10 text-emerald-400 border border-emerald-500/25 animate-pulse" : "bg-blue-500/10 text-blue-400 border border-blue-500/20"
                                }`}>{c.status || "جديد"}</span>
                              </td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  ) : (
                    <div className="p-8 text-center text-gray-500 text-sm">لا يوجد عملاء يطابقون هذه الفئة حالياً في قاعدة البيانات.</div>
                  )}
                </div>
              </div>
            </>
          )}

          {isProjectSelected && !loading ? (
            <div className="transition-all duration-300 space-y-6">
              
              {/* تفعيل نمط التمدد المرن h-full للتعادل البصري ومنع أي حظر قص بـ overflow-hidden */}
              <div className="grid grid-cols-1 xl:grid-cols-2 gap-6 mt-8 items-stretch font-bold text-white text-right">
                <div className="flex flex-col h-full shadow-2xl">
                  {/* معالجة الحفظ المباشر للمتصفح دون التسبب في تداخل كاش سوبابيز */}
                  <CustomerInfo 
                    userRole={userRole} 
                    calculatorEstimate={calculatorEstimate}
                    handleSaveCustomer={async () => {
                      setSaving(true);
                      try {
                        const { data: custData } = await supabase
                          .from("customers")
                          .select("id")
                          .eq("customer_code", crmData.customer.customerCode)
                          .single();

                        if (!custData) throw new Error("فشل العثور على بيانات العميل.");

                        if (crmData.customer.status === "تم التعاقد") {
                          const confirmFreeze = window.confirm(
                            "⚠️ تجميد المقايسة والـ 14 تابة بالكامل وتحويلها إلى وضع القراءة فقط (🔒 Locked) رسمياً.\n\nهل تريد تأكيد التجميد والتعاقد رسميًا؟"
                          );
                          if (!confirmFreeze) {
                            setSaving(false);
                            return;
                          }

                          if (crmData.estimate?.items && crmData.project?.id) {
                            await saveEstimateSnapshot(crmData.estimate.items, crmData.estimate.total);
                          }

                          if (crmData.project?.id) {
                            await supabase
                              .from("projects")
                              .update({ 
                                workflow_stage: "final",
                                unit_status: "جاري التنفيذ الميداني" 
                              })
                              .eq("id", crmData.project.id);
                          }
                        }

                        const { error } = await supabase
                          .from("customers")
                          .update({
                            name: crmData.customer.name,
                            mobile: crmData.customer.mobile,
                            phone: crmData.customer.phone || null,
                            email: crmData.customer.email || null,
                            address: crmData.customer.address || null,
                            status: crmData.customer.status
                          })
                          .eq("id", custData.id);

                        if (error) throw error;

                        // تحديث فوري للقائمة المحلية لمنع الارتداد البصري بعد الـ Render
                        setCustomersList(prev => prev.map(c => c.id === custData.id ? { 
                          ...c, 
                          name: crmData.customer.name,
                          mobile: crmData.customer.mobile,
                          phone: crmData.customer.phone,
                          email: crmData.customer.email,
                          address: crmData.customer.address,
                          status: crmData.customer.status
                        } : c));
                        
                        alert("✅ تم تحديث بيانات العميل وتفعيل بروتوكول التجميد التعاقدي بنجاح!");
                        if (crmData.project?.id) {
                          await loadProjectData(crmData.project.id);
                        }
                      } catch (e: any) {
                        alert("فشل حفظ بيانات العميل: " + e.message);
                      } finally {
                        setSaving(false);
                      }
                    }}
                    saving={saving}
                  />
                </div>
                
                <div className="flex flex-col h-full shadow-2xl">
                  <ProjectInfo 
                    customerProjects={selectedCustomerProjects}
                    handleSwitchActiveProject={handleSwitchActiveProject}
                    handleSaveProject={handleSaveProject}
                    saving={saving}
                    advanceWorkflowStage={advanceWorkflowStage}
                    userRole={userRole}
                  />
                </div>
              </div>

              {/* حاوية الحصر والمساحات الميدانية للغرف والريسبشن */}
              <div className="bg-[#07132a] border-2 border-[#D4AF37] rounded-4xl p-6 shadow-2xl space-y-5">
                <p className="text-[#D4AF37] font-bold flex items-center gap-2 text-xl border-b border-[#D4AF37]/20 pb-3 select-none">
                  <svg className="w-6 h-6 stroke-current fill-none stroke-2 animate-pulse" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                    <rect x="4" y="4" width="16" height="16" rx="2" />
                    <rect x="9" y="9" width="6" height="6" rx="1" />
                    <path d="M9 1v3M15 1v3M9 20v3M15 20v3M20 9h3M20 15h3M1 9h3M1 15h3" />
                  </svg>
                  <span> توزيع وتفاصيل الغرف والمساحات للوحدة</span>
                </p>
                
                <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-3 w-full">
                  <RoomCounterWrapper label="عدد الريسبشن" value={crmData.project?.receptionsCount || 0} field="receptionsCount" />
                  <RoomCounterWrapper label="عدد الغرف" value={crmData.project?.roomsCount || 0} field="roomsCount" />
                  <RoomCounterWrapper label="عدد المطابخ" value={crmData.project?.kitchensCount || 0} field="kitchensCount" />
                  <RoomCounterWrapper label="عدد الحمامات" value={crmData.project?.bathroomsCount || 0} field="bathroomsCount" />
                  <RoomCounterWrapper label="البلكونات" value={crmData.project?.balconiesCount || 0} field="balconiesCount" />
                  <RoomCounterWrapper label="قطع Living" value={crmData.project?.livingCount || 0} field="livingCount" />
                  <RoomCounterWrapper label="الممرات والطرقات" value={crmData.project?.corridorsCount || 0} field="corridorsCount" />
                </div>

                {/* دمج "خط سير العمل المضيء" و "مساحة الجاردن المصغرة" على نفس السطر في سكة عرض أفقية متزنة */}
                <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch w-full">
                  
                  {/* كارت خط سير العمل المضيء الخماسي (العرض الأكبر lg:col-span-8) */}
                  <div className="lg:col-span-8 bg-[#020B1C] p-5 rounded-2xl border border-[#D4AF37]/20 shadow-inner flex flex-col justify-between">
                    <span className="text-[11px] text-[#D4AF37] font-black block text-right">مخطط وجدول خط سير وتدفق صفقات المبيعات حركياً:</span>
                    
                    <div className="flex items-center justify-between relative mt-4 px-2">
                      {/* line connecting nodes */}
                      <div className="absolute top-4.5 left-4 right-4 h-0.5 bg-[#1f2d4d] z-0" />
                      <div 
                        className="absolute top-4.5 right-4 h-0.5 bg-[#D4AF37] z-0 transition-all duration-500" 
                        style={{ width: `${(currentActiveStageIndex / (workflowStages.length - 1)) * 100}%` }}
                      />

                      {workflowStages.map((stage, idx) => {
                        const isCompleted = idx < currentActiveStageIndex;
                        const isActive = idx === currentActiveStageIndex;
                        return (
                          <div key={stage.key} className="flex flex-col items-center z-10 relative">
                            <div 
                              className={`w-9 h-9 rounded-full flex items-center justify-center text-sm font-black transition-all duration-300 border-2 ${
                                isActive 
                                  ? "bg-[#07132a] border-[#D4AF37] text-[#D4AF37] shadow-[0_0_15px_rgba(212,175,55,0.6)] scale-110" 
                                  : isCompleted 
                                    ? "bg-[#D4AF37] border-[#D4AF37] text-[#020B1C]" 
                                    : "bg-[#020B1C] border-[#1f2d4d] text-gray-500"
                              }`}
                              title={stage.label}
                            >
                              {isCompleted ? <Check size={14} className="stroke-3" /> : <span>{stage.icon}</span>}
                            </div>
                            <span className={`text-[9px] mt-2 font-black tracking-tighter transition-colors ${isActive ? 'text-[#D4AF37]' : 'text-gray-500'}`}>
                              {stage.label}
                            </span>
                          </div>
                        );
                      })}
                    </div>
                  </div>

                  {/* كارت الحديقة / الجاردن المصغر (العرض الأصغر lg:col-span-4 لضغط المساحة المهدرة) */}
                  <div className="lg:col-span-4 border border-[#D4AF37]/20 rounded-2xl p-5 bg-[#0b1b3d]/40 shadow-xl flex flex-col justify-between space-y-4">
                    <div className="flex items-center justify-between gap-4 select-none">
                      <div className="text-right flex-1">
                        <h4 className="text-[#D4AF37] text-xs font-black">الحديقة المفتوحة للوحدة (جاردن)</h4>
                        <p className="text-gray-400 text-[10px] mt-1">تخصيص مساحة اللاندسكيب للوحدة الأرضية:</p>
                      </div>
                      <div className="w-8 h-8 rounded-lg bg-[#D4AF37]/10 border border-[#D4AF37]/30 text-[#D4AF37] flex items-center justify-center shrink-0">
                        <svg className="w-4 h-4 stroke-current fill-none stroke-2" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                          <path d="m3 9 9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z" />
                          <polyline points="9 22 9 12 15 12 15 22" />
                        </svg>
                      </div>
                    </div>

                    <div className="p-2 rounded-xl bg-[#020B1C] border border-[#1f2d4d] flex items-center justify-between h-10 gap-3">
                      <div className="flex items-center gap-2 bg-[#07132a] border border-[#1f2d4d] px-2 py-0.5 rounded-lg h-7 select-none" dir="ltr">
                        <button
                          type="button" 
                          disabled={isLocked}
                          onClick={() => {
                            const currentArea = Number(crmData.project?.gardenArea || 0);
                            const calculated = Math.max(0, currentArea - 5);
                            setCRMData((prev: any) => ({
                              ...prev,
                              project: { 
                                ...(prev.project || {}), 
                                gardenArea: calculated,
                                gardenExist: calculated > 0
                              }
                            }));
                          }}
                          className="w-5 h-5 bg-rose-950/40 border border-rose-500/30 hover:bg-rose-600 text-rose-400 hover:text-white rounded-full flex items-center justify-center font-bold text-xs cursor-pointer transition active:scale-90 disabled:opacity-40"
                        >
                          <Minus size={10} className="stroke-3" />
                        </button>
                        
                        <span className="text-[#D4AF37] font-black font-mono text-xs min-w-4.5 text-center">
                          {crmData.project?.gardenArea || 0}
                        </span>
                        
                        <button
                          type="button" 
                          disabled={isLocked}
                          onClick={() => {
                            const currentArea = Number(crmData.project?.gardenArea || 0);
                            const calculated = currentArea + 5;
                            setCRMData((prev: any) => ({
                              ...prev,
                              project: { 
                                ...(prev.project || {}), 
                                gardenArea: calculated,
                                gardenExist: true
                              }
                            }));
                          }}
                          className="w-5 h-5 bg-[#020B1C] border border-[#243556] hover:border-[#D4AF37] hover:bg-[#D4AF37] hover:text-[#020B1C] text-[#D4AF37] rounded-full flex items-center justify-center font-bold text-xs cursor-pointer transition active:scale-90 disabled:opacity-40"
                        >
                          <Plus size={10} className="stroke-3" />
                        </button>
                      </div>
                      <span className="text-[#00FF00] font-bold text-[10px] select-none text-left font-mono">المساحة م²</span>
                    </div>
                  </div>

                </div>

              </div>

              {userRole !== "engineer" && (
                <div className="bg-[#07132a] border border-[#d4af37] rounded-2xl p-6 space-y-4 shadow-2xl animate-fade-in">
                  <div className="flex justify-between items-center border-b border-[#d4af37] pb-3 select-none">
                    <h3 className="text-[#D4AF37] text-lg md:text-xl font-bold flex items-center justify-center gap-3 leading-none tracking-wide">
                      <span>📞 سجل المحادثات والمتابعة للعميل</span>
                    </h3>
                    <button
                      type="button" // 👈 منع إعادة التحميل الافتراضية
                      onClick={(e) => { e.preventDefault(); setIsFollowUpOpen(true); }}
                      className="text-[#D4AF37] hover:text-[#F0E6D2] active:scale-90 transition duration-150 cursor-pointer shrink-0 p-1 block"
                    >
                      <svg className="w-8 h-8 stroke-current fill-none stroke-[2.5]" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                        <line x1="12" y1="5" x2="12" y2="19" />
                        <line x1="5" y1="12" x2="19" y2="12" />
                      </svg>
                    </button>
                  </div>

                  <div className="space-y-4 max-h-112.5 overflow-y-auto pr-2">
                    {loadingLogs ? (
                      <p className="text-center text-gray-500 text-sm animate-pulse">جاري سحب سجل المحادثات...</p>
                    ) : customerLogs.length > 0 ? (
                      <>
                        {customerLogs.slice(0, visibleLogsCount).map((log) => (
                          <div key={log.id} className="bg-[#020B1C] border border-[#D4AF37]/20 p-4 rounded-xl space-y-2 relative transition hover:border-[#D4AF37]/40 shadow-inner">
                            <div className="flex justify-between items-center text-xs text-gray-500 border-b border-[#1f2d4d] pb-1">
                              <span className="font-bold text-[#D4AF37]">◀ {log.interaction_type}</span>
                              {/* دمج وعرض دالة التنسيق العربية الجديدة المانعة لتشتت الأرقام */}
                              <span className="font-mono">{formatTimelineDate(log.created_at)}</span>
                            </div>
                            <p className="text-white text-sm leading-relaxed font-bold whitespace-pre-wrap">{log.feedback}</p>
                            {log.next_follow_up_date && (
                              <div className="text-xs text-amber-400 font-bold pt-1 border-t border-[#1f2d4d]/30 flex justify-between">
                                <span>📅 موعد الاتصال القادم:</span>
                                <span className="font-mono">{log.next_follow_up_date}</span>
                              </div>
                            )}
                          </div>
                        ))}

                        {customerLogs.length > visibleLogsCount && (
                          <button
                            type="button" 
                            onClick={(e) => { e.preventDefault(); setVisibleLogsCount(prev => prev + 10); }}
                            className="w-full py-3 bg-[#020B1C] border border-[#243556] text-[#D4AF37] hover:border-[#D4AF37] hover:text-white font-extrabold text-xs rounded-xl transition cursor-pointer text-center"
                          >
                            🔽 عرض المزيد من المتابعات السابقة ({customerLogs.length - visibleLogsCount} متبقية)
                          </button>
                        )}
                      </>
                    ) : (
                      <div className="p-8 text-center text-gray-500 text-sm bg-[#020B1C]/50 rounded-xl border border-dashed border-[#D4AF37]/25">
                        لا توجد متابعة مسجلة لهذا العميل من قبل.
                      </div>
                    )}
                  </div>
                </div>
              )}

              {(userRole === "engineer" || userRole === "admin" || userRole === "owner" || userRole === "manager") ? (
                <div className="mt-8">
                  <FinishingTabs />
                </div>
              ) : (
                <div className="mt-8 p-12 border-2 border-dashed border-[#D4AF37]/25 rounded-2xl text-center">
                  <p className="text-[#F0E6D2] text-lg font-bold mb-2">📐 مواصفات التشطيب وإعداد المقايسة من اختصاص فريق المهندسين</p>
                </div>
              )}

            </div>
          ) : (
            !loading && (
              <div className="mt-12 p-12 border-2 border-dashed border-[#D4AF37]/25 rounded-2xl text-center select-none bg-[#07132a]">
                <p className="text-[#F0E6D2] text-lg font-bold mb-2">مرحباً بك في برنامج Golden Decoration ERP لإدارة الديكور الذكي</p>
              </div>
            )
          )}

          {isFollowUpOpen && (
            <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4 text-right animate-fade-in select-none">
              <div className="bg-[#07132a] border border-[#D4AF37] rounded-3xl p-6 w-full max-w-md shadow-2xl relative space-y-4 text-white">
                <div className="flex justify-between items-center border-b border-[#D4AF37] pb-3">
                  <h4 className="text-[#D4AF37] font-bold text-lg">📞 تسجيل متابعة جديدة للعميل</h4>
                  <button 
                    type="button" 
                    onClick={(e) => { e.preventDefault(); setIsFollowUpOpen(false); }} 
                    className="text-gray-400 hover:text-rose-500 font-bold text-sm cursor-pointer"
                  >
                    ✕
                  </button>
                </div>

                <div className="space-y-4 text-sm font-bold">
                  <div>
                    <label className="block text-[#D4AF37] font-bold mb-1.5">نوعية الاتصال والمتابعة</label>
                    <select
                      value={followUpType}
                      onChange={(e) => setFollowUpType(e.target.value)}
                      className="w-full h-11 rounded-lg bg-[#020B1C] border border-[#D4AF37]/25 text-[#D4AF37] font-bold px-3 outline-none focus:border-[#D4AF37]"
                    >
                      <option value="مكالمة هاتفية">📞 مكالمة هاتفية صادر</option>
                      <option value="محادثة واتساب">💬 محادثة واتساب</option>
                      <option value="مقابلة بموقع العميل">📍 مقابلة بموقع العميل</option>
                      <option value="اجتماع بمقر الشركة">🏢 اجتماع بمقر الشركة</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-[#D4AF37] font-bold mb-1.5">تفاصيل المحادثة والاتفاق  *</label>
                    <textarea
                      rows={3}
                      placeholder="ملخص الاتصال ..."
                      value={followUpFeedback}
                      onChange={(e) => setFollowUpFeedback(e.target.value)}
                      className="w-full rounded-lg bg-[#020B1C] border border-[#D4AF37]/25 text-white p-3 outline-none text-right font-medium focus:border-[#D4AF37]"
                    />
                  </div>

                  <div>
                    <label className="block text-[#D4AF37] font-bold mb-1.5">موعد المكالمة / المتابعة القادمة</label>
                    <input
                      type="date"
                      value={followUpNextDate}
                      onChange={(e) => setFollowUpNextDate(e.target.value)}
                      className="w-full h-11 rounded-lg bg-[#020B1C] border border-[#D4AF37]/25 text-[#D4AF37] font-bold px-3 outline-none font-mono focus:border-[#D4AF37]"
                    />

                    <div className="flex items-center gap-2 mt-2 flex-wrap">
                      <button
                        type="button" 
                        onClick={(e) => { e.preventDefault(); setQuickFollowUpDate(1); }}
                        className="px-3 py-1.5 bg-[#020B1C] border border-[#D4AF37]/20 text-xs text-[#D4AF37] hover:border-[#D4AF37] rounded-lg transition active:scale-95 cursor-pointer"
                      >
                        ⏳ غداً
                      </button>
                      <button
                        type="button" 
                        onClick={(e) => { e.preventDefault(); setQuickFollowUpDate(3); }}
                        className="px-3 py-1.5 bg-[#020B1C] border border-[#D4AF37]/20 text-xs  text-[#D4AF37] hover:border-[#D4AF37] rounded-lg transition active:scale-95 cursor-pointer"
                      >
                        ⏳ بعد 3 أيام
                      </button>
                      <button
                        type="button" 
                        onClick={(e) => { e.preventDefault(); setQuickFollowUpDate(7); }}
                        className="px-3 py-1.5 bg-[#020B1C] border border-[#D4AF37]/20 text-xs  text-[#D4AF37] hover:border-[#D4AF37] rounded-lg transition active:scale-95 cursor-pointer"
                      >
                        ⏳ بعد أسبوع
                      </button>
                    </div>
                  </div>
                </div>

                <div className="pt-4 border-t border-[#243556]">
                  {/* 🌟 تحديث وإعادة هيكلة زرار المتابعة التاريخية للدستور البصري الحركي الموحد */}
                  <button
                    type="button" 
                    onClick={(e) => { e.preventDefault(); handleSaveFollowUp(); }}
                    disabled={saving}
                    className="px-6 h-12 rounded-xl bg-linear-to-b from-[#0c1e3d] to-[#040e20] text-[#D4AF37] border-2 border-[#D4AF37] shadow-[0_0_20px_rgba(212,175,55,0.25)] hover:shadow-[0_0_30px_rgba(212,175,55,0.45)] hover:scale-[1.03] active:scale-95 transition-all duration-300 cursor-pointer text-xs font-black flex items-center justify-center gap-1.5 select-none relative overflow-hidden disabled:opacity-50 w-full"
                  >
                    {saving ? "جاري الحفظ والمزامنة..." : "💾 حفظ المتابعة التاريخية للعميل"}
                    <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-linear-to-r from-transparent via-[#D4AF37] to-transparent shadow-[0_-1px_6px_rgba(212,175,55,0.8)]" />
                  </button>
                </div>
              </div>
            </div>
          )}

        </div>
      </section>
    </main>
  );

  function RoomCounterWrapper({ label, value, field }: { label: string, value: number, field: string }) {
    return (
      <div className="flex flex-row items-center justify-between bg-[#020B1C] border border-[#D4AF37]/15 px-3.5 rounded-xl transition-all hover:border-[#D4AF37]/35 shadow-inner group w-full h-11 select-none font-alexandria">
        
        <label className="text-white font-bold text-xs select-none truncate pr-1 group-hover:text-[#F0E6D2] cursor-pointer">
          {label}
        </label>
        
        <div className="flex items-center gap-2.5" dir="ltr">
          <button
            type="button"
            disabled={isLocked}
            onClick={() => {
              if (isLocked) return;
              setCRMData((prev: any) => ({
                ...prev,
                project: { ...(prev.project || {}), [field]: Math.max(0, value - 1) }
              }));
            }}
            className="w-6 h-6 flex items-center justify-center bg-[#9B1C1C]/25 border border-[#9B1C1C]/60 hover:bg-[#9B1C1C] text-[#ff6b6b] hover:text-white rounded-full transition cursor-pointer active:scale-90 font-bold select-none disabled:opacity-40"
          >
            <Minus size={12} className="stroke-3" />
          </button>
          
          <span className="text-sm font-black text-[#D4AF37] font-mono min-w-4 text-center select-none">
            {value}
          </span>
          
          <button
            type="button"
            disabled={isLocked}
            onClick={() => {
              if (isLocked) return;
              setCRMData((prev: any) => ({
                ...prev,
                project: { ...(prev.project || {}), [field]: value + 1 }
              }));
            }}
            className="w-6 h-6 flex items-center justify-center bg-[#020B1C] border border-[#243556] hover:border-[#D4AF37] hover:bg-[#D4AF37] hover:text-[#020B1C] text-[#D4AF37] rounded-full transition cursor-pointer active:scale-90 font-bold select-none disabled:opacity-40"
          >
            <Plus size={12} className="stroke-3" />
          </button>
        </div>

      </div>
    );
  }
}